$(function(){
  console.log("准备好了");
})
